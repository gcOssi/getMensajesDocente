@XmlSchema(
    namespace = "http://sap.fusesource.org/rfc/DEV/ZCM_LVC_CHANGE_RATING_RFC",
    elementFormDefault = XmlNsForm.QUALIFIED,
    xmlns = {
        @XmlNs(prefix="ZCM_LVC_CHANGE_RATING_RFC", namespaceURI="http://sap.fusesource.org/rfc/DEV/ZCM_LVC_CHANGE_RATING_RFC")
    }
)  

package cl.duoc.servicios.practicas.rest;
import javax.xml.bind.annotation.*;
